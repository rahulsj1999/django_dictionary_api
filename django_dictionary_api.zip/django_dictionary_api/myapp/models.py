from django.db import models

# Create your models here.
class Dictionary(models.Model):
    word = models.CharField(max_length=255, unique=True)
    description = models.TextField()
    synonyms = models.JSONField()
    antonyms = models.JSONField()
    
    def __str__(self):
        return self.word