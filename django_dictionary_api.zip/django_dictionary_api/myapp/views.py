from django.shortcuts import render, redirect
from django.http import HttpResponse
from myapp.forms import DictionaryForm
# Create your views here.

def dictionaryform(request):
    if request.method == "POST":
        form = DictionaryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dictform')
    else:
        form = DictionaryForm()
    return render(request, 'index.html', {'form' : form})
