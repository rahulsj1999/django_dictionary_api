from django.contrib import admin
from myapp.models import Dictionary

admin.site.register(Dictionary)