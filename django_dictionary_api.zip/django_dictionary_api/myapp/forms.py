from django.forms import ModelForm
from myapp.models import Dictionary
class DictionaryForm(ModelForm):
    class Meta:
        model = Dictionary
        fields = '__all__'