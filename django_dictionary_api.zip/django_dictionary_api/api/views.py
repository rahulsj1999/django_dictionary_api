from django.http import JsonResponse, HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import DictionarySerializer
from myapp.models import Dictionary

def dictionary_info(request):
    return HttpResponse("Dictionary info")

@api_view(['GET'])
def get_all_words(request):
    all_words = Dictionary.objects.all()
    serializer = DictionarySerializer(all_words, many=True)
    return Response({"data": serializer.data})

@api_view(['GET'])
def get_word(request, word):
    word = get_object_or_404(Dictionary, word=word)
    serializer = DictionarySerializer(word, many=False)
    return Response({"data": [serializer.data]})
