from django.urls import path
from api import views
from rest_framework.generics import ListCreateAPIView

urlpatterns = [
    path('', views.dictionary_info),
    path('words/', views.get_all_words),
    path('words/<str:word>', views.get_word)
]
