from rest_framework import serializers
from myapp.models import Dictionary
from rest_framework import generics

    
class DictionarySerializer(serializers.ModelSerializer):
    class Meta:
        model = Dictionary
        fields = "__all__"